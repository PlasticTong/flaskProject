"""
Contains a collection of algorithms and measures for networks, higher-order models, and paths
"""